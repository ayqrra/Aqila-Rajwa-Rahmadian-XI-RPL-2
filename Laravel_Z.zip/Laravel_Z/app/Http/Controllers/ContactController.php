<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    // Menampilkan daftar semua kontak
    public function index()
    {
        $contacts = Contact::all(); // Mengambil semua kontak dari database
        return view('contacts.index', compact('contacts')); // Mengirim data ke view
    }

    // Menampilkan form untuk menambahkan kontak baru
    public function create()
    {
        return view('contacts.create'); // Menampilkan form tambah kontak
    }

    // Menyimpan kontak baru ke database
    public function store(Request $request)
    {
        // Validasi input
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:contacts',
        ]);
    
        // Membuat kontak baru
        Contact::create($request->only(['name', 'email'])); // Hanya ambil kolom yang diizinkan
        return redirect()->route('contacts.index')->with('success', 'Kontak berhasil ditambahkan.');
    }
    

    // Menampilkan kontak berdasarkan ID
    public function show($id)
    {
        $contact = Contact::findOrFail($id); // Mengambil kontak berdasarkan ID
        return view('contacts.show', compact('contact')); // Menampilkan detail kontak
    }

    // Menampilkan form untuk mengedit kontak
    public function edit($id)
    {
        $contact = Contact::findOrFail($id); // Mengambil kontak berdasarkan ID
        return view('contacts.edit', compact('contact')); // Menampilkan form edit
    }

    // Memperbarui kontak di database
    public function update(Request $request, $id)
    {
        // Validasi input
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:contacts,email,' . $id,
        ]);

        // Mengupdate kontak
        $contact = Contact::findOrFail($id);
        $contact->update($request->all());
        return redirect()->route('contacts.index')->with('success', 'Kontak berhasil diperbarui.'); // Redirect ke index
    }

    // Menghapus kontak dari database
    public function destroy($id)
    {
        $contact = Contact::findOrFail($id); // Mengambil kontak berdasarkan ID
        $contact->delete(); // Menghapus kontak
        return redirect()->route('contacts.index')->with('success', 'Kontak berhasil dihapus.'); // Redirect ke index
    }
}

