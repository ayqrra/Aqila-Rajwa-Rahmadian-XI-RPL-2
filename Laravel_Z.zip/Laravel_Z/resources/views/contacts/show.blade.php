@extends('layouts.app')

@section('content')
    <h1 class="my-4">Detail Kontak</h1>

    <p><strong>Nama:</strong> {{ $contact->name }}</p>
    <p><strong>Email:</strong> {{ $contact->email }}</p>

    <a href="{{ route('contacts.index') }}" class="btn btn-secondary">Kembali</a>
@endsection
