<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ContactController;

// Rute untuk resource Contact
Route::resource('contacts', ContactController::class);
